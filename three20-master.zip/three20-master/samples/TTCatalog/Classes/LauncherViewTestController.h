#import <Three20/Three20.h>

@interface LauncherViewTestController : TTViewController <TTLauncherViewDelegate> {
  TTLauncherView* _launcherView;
}

@end
