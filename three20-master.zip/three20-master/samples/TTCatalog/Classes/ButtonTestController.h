#import <Three20/Three20.h>

@interface ButtonTestController : TTViewController {
  CGFloat _fontSize;
}

@end
