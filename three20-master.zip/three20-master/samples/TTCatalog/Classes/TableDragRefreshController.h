#import <Three20/Three20.h>

@interface TableDragRefreshController : TTTableViewController

@end
