#import <Three20/Three20.h>

@interface ActivityTestController : TTViewController
@end

